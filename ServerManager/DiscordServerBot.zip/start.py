import os
os.system("""
pip install -r requirements.txt
clear
python3 main.py
""")